//
//  ViewController.m
//  radialmenuexample
//
//  Created by MACOS on 01/08/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    DPRadialMenu *radialMenu = [[DPRadialMenu alloc] init];
    DPRadialMenu *radialMenuSmall = [[DPRadialMenu alloc] init];
    
    UIButton *b1 = [[UIButton alloc] init];
    UIButton *b2 = [[UIButton alloc] init];
    UIButton *b3 = [[UIButton alloc] init];
    
    [b1 setTitle:@"1" forState:UIControlStateNormal];
    [b2 setTitle:@"2" forState:UIControlStateNormal];
    [b3 setTitle:@"3" forState:UIControlStateNormal];
    
    [radialMenu configureWithButtons:@[b1, b2, b3] view:self.view delegate:self];
    
    // Display or not the fade vuew on the background
    radialMenu.displayBackgroundView = YES;
    
    // Animations time
    radialMenu.animationTime = 0.5;
    
     radialMenuSmall.actionView = self.view;

    // Do any additional setup after loading the view, typically from a nib.
}

- (void) radialMenu:(DPRadialMenu *)radialMenu didSelectButton:(UIButton *)selectedButton {
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Button selected"
                                 message:[NSString stringWithFormat:@"%@", selectedButton]
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
    }];
    [alert addAction:okAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void) radialMenuDidCancel:(DPRadialMenu *)radialMenu {
    NSLog(@"Canceled");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
